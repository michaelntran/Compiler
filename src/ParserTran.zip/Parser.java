package parser;

import java.util.HashMap;
import java.util.Map;

import scanner.*;

/**
 * This parser class acts as the parser component of the compiler built in the compilers class
 * @author Michael Tran
 * @version 10/1/2019
 */
public class Parser {
	
	Scanner sc;
	String currentToken;
	Map<String, Integer> vars = new HashMap<String, Integer>();
	
	public Parser(Scanner scanner)
	{
		sc = scanner;
		currentToken = sc.nextToken();
	}
	
	/**
	 * Eats the next token using the scanner's next method
	 * @param expected is the expected token
	 * @throws IllegalArgumentException if expected does not match currentToken
	 */
	private void eat(String expected)
	{
		if(expected.equals(currentToken))
		{
			currentToken = sc.nextToken();
		}
		else
		{
			throw new IllegalArgumentException("expected: " + currentToken + " but found: " + expected);
		}
	}
	
	/**
	 * This method parses a number using the eat method
	 * @precondition current token is an integer
	 * @postcondition number token has been eaten 
	 * @return the value of the parsed integer
	 */
	private int parseNumber()
	{
		int num = Integer.parseInt(currentToken);
		eat(currentToken);
		return num;
	}
	
	/**
	 * This method parses a statement using the eat method
	 * @precondition current token is a statement
	 * @postcondition statement token has been eaten
	 */
	public void parseStatement()
	{
		if(currentToken.equals("WRITELN"))
		{
			eat("WRITELN");
			eat("(");
			System.out.println(parseExpression());
			eat(")");
			eat(";");
		}
		else if(currentToken.equals("BEGIN")){
			eat("BEGIN");
			while(!currentToken.equals("END"))
			{
				parseStatement();
			}
			eat("END");
			eat(";");
		}
		else {
			String varName = currentToken;
			eat(currentToken);
			eat(":=");
			int varValue = parseExpression();
			vars.put(varName, varValue);
			eat(";");
		}
	}
	
	/**
	 * parses a factor using the eat method
	 * @precondition current token is a factor
	 * @postcondition factor token has been eaten
	 * @return the evaluated factor
	 */
	public int parseFactor()
	{
		int factor;
		if(currentToken.equals("-"))
		{
			eat(currentToken);
			factor = -parseFactor();
		}
		else if(currentToken.equals("("))
		{
			eat("(");
			factor = parseExpression();
			eat(")");
		}
		else if(sc.isDigit(currentToken.charAt(0)))
		{
			factor = parseNumber();
		}
		else {
			factor = vars.get(currentToken);
			eat(currentToken);
		}
		return factor;
	}
	
	/**
	 * parses a term using the eat method
	 * @precondition current token is a term
	 * @postcondition term token has been eaten
	 * @return the evaluated term
	 */
	public int parseTerm()
	{
		int term = parseFactor();
		while(currentToken.equals("*") || currentToken.equals("/"))
		{
			if(currentToken.equals("*"))
			{
				eat("*");
				term *= parseFactor();
			}
			if(currentToken.equals("/"))
			{
				eat("/");
				term /= parseFactor();
			}
		}
		return term;
	}
	
	/**
	 * parses an expression using the eat method
	 * @precondition current token is an expression
	 * @postcondition expression token has been eaten
	 * @return the evaluated expression
	 */
	public int parseExpression()
	{
		int exp = parseTerm();
		while(currentToken.equals("+") || currentToken.equals("-"))
		{
			if(currentToken.equals("+"))
			{
				eat("+");
				exp += parseTerm();
			}
			if(currentToken.equals("-"))
			{
				eat("-");
				exp -= parseTerm();
			}
		}
		return exp;
	}
}
